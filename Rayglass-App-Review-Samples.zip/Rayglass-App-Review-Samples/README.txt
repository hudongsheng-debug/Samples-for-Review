Rayglass / Rayglass Mobile — App Review Samples

Five synthetic .rayglass design files, shared by macOS and iPadOS.
These are JSON-based optical projects, not FITS images or manufacturing
prescriptions. The same files were decoded, validated and analyzed with
both local platform cores. The beam-splitter scene was traced and the
coating design validated on both. This does not constitute device UI testing.

OPENING THE FILES
Mac: extract the ZIP in Finder; in Rayglass use Open and choose a .rayglass
file from Samples.
iPad: download in Safari, find the ZIP in Files (Downloads), tap to extract,
then in Rayglass Mobile use Open and select the extracted .rayglass file.
Use the Parameters slider button to edit system/surface settings. Reveal
the sidebar with its button if it is hidden. Select a surface card to edit it.
No sign-in, external optical software, hardware or network service is
needed. The built-in Examples menu is an immediate alternative to downloading.

SEQUENTIAL OPTICS
01_Singlet.rayglass: open, select Optical Design and click/tap Trace.
Inspect the lens surfaces, traced layout and Spot Analysis for the supplied
fields and wavelengths. Use Autofocus and Trace again. Change a surface
parameter and trace again; use Undo/Redo to review editing behavior.
02_Doublet.rayglass: repeat with a cemented doublet starting design.
03_Parabolic_Mirror.rayglass: repeat with a reflecting surface and conic -1.
These designs demonstrate different layouts; nonzero aberrations are expected.

ADDITIONAL ANALYSES (use the singlet)
Aberrations & Fields: run Calculate Aberrations and inspect the curves.
Wavefront & Diffraction: use Calculate Wavefront & Diffraction at the
default sampling and inspect the available wavefront, PSF and MTF results.
Optimization & Scans: Add Variable (the default is a last-surface thickness
variable with bounds), then Scan First Variable or Run Local Optimization.
Tolerance Analysis: Add Variable, choose 10 trials and an integer seed,
then Run Monte Carlo. Results distinguish failed trials from valid trials.
These controls require a selected variable; they are not automatic on import.
Materials and Elements & Examples: browse the catalog and built-in examples;
loading an example replaces the active working design, so save edits first.

NON-SEQUENTIAL AND COATING PROJECTS
04_Beam_Splitter.rayglass: select Non-sequential Trace and use Trace to run
the embedded scene. Inspect ray paths, detectors and power accounting.
05_Multilayer_Coating.rayglass: select Coating Analysis. Inspect the
reflectance/transmittance spectrum, layer list and angle/polarization controls.
The coating view evaluates its own model; the main sequential Trace control
is disabled on that page by design. These projects also retain a singlet
sequential prescription so the main optical design remains valid.

SAVE, REOPEN AND EXPORT
Save a design to a new .rayglass file and reopen it using Open. Run analyses
again after reopening; do not assume plots are stored in the project file.
Use Exchange to export sequential layout PNG, sequential analysis report,
and optical-surface CSV. The sequential report requires completed analysis.
To test CSV import, export the singlet's surface CSV and import that file
back into a copy of the singlet project. Analysis pages offer additional
result exports, including MTF CSV and tolerance-trial CSV after calculation.
On iPad use the system file exporter to choose the output location.
The Guide explains supported optical models and limits. Examples illustrate
local analysis workflows, not a claim of manufacturing-ready optical quality.
