LumaPair for FITS — App Review Samples

Extract the ZIP before opening files in Samples. All three files are
synthetic, uncompressed, floating-point 2D FITS primary images. They
contain no observational or personal data. No sign-in, hardware,
companion app or network service is needed for the comparison workflow.

FILES
01_Reference_A.fits — 256 x 192 reference field with four bright sources.
02_Changed_B.fits — the same field with an additional bright source.
03_Different_Size_B.fits — 128 x 128 image for the size-mismatch workflow.
The added source in image B is near 75% of the image width from the left
and 66% of the image height from the top (FITS center X=191, Y=66,
using one-based pixel coordinates). A and B share the same pixel grid.

QUICK REVIEW
1. Launch LumaPair. Click Open A... and select 01_Reference_A.fits.
   Click Open B... and select 02_Changed_B.fits. Both show 256 x 192,
   image HDU 0. Click Fit if needed to see the whole image.
2. Select Wipe. Move the vertical divider or the lower slider across
   the added source. Image A is on the left and B on the right. The
   extra source appears when that location is revealed from image B.
3. Select Blink. The extra source alternates between absent and present.
   Change the interval, click Pause, then use Toggle A / B to switch
   manually. Click Play to resume.
4. Select Overlay. Move the opacity slider from A to B. The additional
   source fades in as B's contribution increases. This blends previews;
   it is not a numerical difference image.
5. Adjust Shared Display: black/white limits, Linear/Asinh/Logarithmic
   stretch, and Grayscale/Aurora palette. Both images use the same
   display settings. Use Reset Display to return to the defaults.
6. Zoom by scrolling or pinching, and drag to pan. In Wipe, drag away
   from the divider to pan. Click Fit or double-click to reset the view.
7. Use the swap button between the file names to exchange A and B.
   The additional source now belongs to A. Swap back before the next step.
8. Keep 01_Reference_A.fits in A. Use Open B... to open
   03_Different_Size_B.fits. The dimensions differ, so the application
   uses side-by-side viewing instead of the shared comparison modes.
   This is expected behavior. Reopen 02_Changed_B.fits in B to restore
   the matching pair and test Wipe, Blink or Overlay again.

BUILT-IN DEMO
Load Demo opens an additional simulated pair with a changed bright feature.
It can be used to review the comparison modes without external files.

EXPECTED BEHAVIOR AND VALIDATION
All three supplied files were successfully loaded and rendered using the
local LumaPair parsing/rendering code. The matching pair passed the size
compatibility check, the different-size pair did not, and the added source
has a peak difference of 220 in the synthetic source pixel units.
LumaPair is a visual comparison app; it does not offer numerical difference
measurements, automatic alignment, photometry, saved sessions or report
export. Original files remain unchanged. Reopen A and B after relaunch
because comparison sessions are not saved. These samples are a focused
workflow demonstration, not an exhaustive FITS compatibility suite.
