StarGauge for FITS — App Review Samples

Extract the ZIP before opening the FITS files. These are synthetic test
images, not observations. No login or additional application is needed.
All images are 256 x 256 pixels. Coordinates below are 1-based, Y upwards.

QUICK START: STAR MEASUREMENT
1. Launch StarGauge and click Open FITS... Select Samples/01_Round_Star.fits.
2. Select Star / aperture and click the bright star at the image center.
3. Set Radius to 16, Ring inner radius to 22, and Ring outer radius to 30.
   Use Center on measured star to refine the position.
4. Inspect the results and radial brightness chart; scroll the results
   panel if needed. The centroid should be near X=128, Y=128, background
   near 100, net flux near 56549, and major/minor FWHM near 7.06 pixels.
   Ellipticity should be near 0. Small differences from manual placement
   are expected. These are moment estimates, not fitted/calibrated values.
5. Change Stretch (Asinh, Linear, Log), Brightness, and zoom. These affect
   the preview; the same selection retains the same numerical results.

REGION MEASUREMENT
6. Choose Rectangle and drag between opposite corners of a region.
   Inspect valid pixels, mean, median, min/max, standard deviation and sum.
7. Choose Circle and drag from its center to its edge. Inspect the results.
   Reset region returns the selection to its default size/location.

MULTIPLE IMAGE HDUS
8. Open Samples/02_MultiHDU_Stars.fits. The HDU menu offers two image HDUs.
   The primary image contains the round star. Select the ELLIPTICAL image
   extension and repeat the centered star measurement with radii 16/22/30.
   Expected centroid: approximately (128,128); background: 100;
   net flux: about 50262; major/minor FWHM: about 9.41 / 4.71 pixels;
   ellipticity: approximately 0.50.

FITS SCALING AND INVALID PIXELS
9. Open Samples/03_Scaled_Masked_Field.fits. This integer image uses
   BSCALE=2 and BZERO=50; all valid source values become 100 after scaling.
   One central BLANK pixel is invalid. In Rectangle mode, draw a region
   around the image center. Expected mean/median/min/max: 100; standard
   deviation: 0; one excluded-pixel warning when the region includes the
   center. A flat preview is expected. There is no star in this file, so
   unavailable star shape in Star / aperture mode is expected behavior.

SAVE, RENAME, RESTORE, EXPORT
10. Reopen 01_Round_Star.fits and make a star measurement. Click Save at
    the top of the results panel. Make and save a second measurement.
11. Scroll to saved records, select one, enter a name and click Rename.
    Inspect its details. Reapply region to current image restores its
    selection when the same original image and HDU are open.
12. Use Export > Measurements CSV... to export saved measurements.
    With no saved records, this exports the current result instead.
13. With a current measurement, use Export > Annotated PNG... .
    In Star / aperture mode, use Export > Radial profile CSV... .
14. Quit and reopen StarGauge. Saved records should remain. Reopen the
    same FITS file/HDU before reapplying a record's region; source images
    are not automatically reopened. Optional: remove a sample measurement
    and use Undo deletion to restore it in the same session.

BUILT-IN DEMO
Load Demo provides another simulated star field without downloading files.
A star is already selected. It can also be used for measurements, display
controls, saved records and exports. Help explains measurement conventions.

VALIDATION AND SCOPE
The supplied files were read and measured successfully with the local
StarGauge FITS reader and measurement code. Expected values above came
from centered selections using that code. These samples cover the main
interactive workflow and multiple image HDUs, scaling and invalid pixels;
they are not an exhaustive test of all supported FITS formats.
Original FITS source files are not modified by measurements or exports.
