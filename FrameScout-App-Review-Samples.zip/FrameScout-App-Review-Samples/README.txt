FrameScout for FITS — App Review Sample Files

These are synthetic demonstration images, not scientific observations.
No account or additional application is needed for the workflow below.
Extract this ZIP before importing the FITS files.

SAMPLE CONTENTS
All three files are uncompressed 256 x 192, 32-bit floating-point, 2D
primary FITS images. Each header includes an exposure and SATURATE=1000.

01_Clear.fits: clear synthetic star field; exposure 60 seconds.
  Expected min/max approximately 27.686 / 631.93; saturation 0.00%.
02_Saturated.fits: brighter field with clipped star cores; exposure 60 seconds.
  Expected maximum 1000; saturated fraction approximately 1.89%.
03_Faint.fits: faint, noisy field; exposure 10 seconds.
  Expected min/max approximately 3.0573 / 113.10; saturation 0.00%.

REVIEW WALKTHROUGH
1. Launch FrameScout for FITS. Choose Import FITS... in the toolbar
   (or Command-O), then select the three .fits files in Samples.
2. Select each file in the sidebar. Check the grayscale image preview,
   Image Details and Sample Statistics. Each image is 256 x 192;
   Image HDU is 0; Sampled Pixels is 49152; invalid fraction is 0.00%.
   Preview uses automatic stretching, so the faint image may appear bright.
   Statistics use source pixel values, not the stretched preview.
3. Select 01_Clear.fits and click Keep. Select 02_Saturated.fits and
   click Reject. Leave 03_Faint.fits Unreviewed (or click Unreviewed).
   These decisions are made by the reviewer, not automatically by the app.
4. Enter a note in Review Notes, for example "App Review sample note".
5. Enter Clear in Search filenames and confirm the clear sample appears.
   Clear the search. Use the Review Status menu to inspect each status,
   then return to All Files.
6. Choose Export Kept Files... (Shift-Command-E), and select a writable
   destination folder. The app creates a new export folder with a copy of
   the kept FITS file and FrameScout-report.csv. The CSV contains review
   records, statistics and notes. Rejected and unreviewed FITS files are
   not copied. Reject does not delete the source file.
   If the review list already contains other files, their statuses also
   affect the export; the expected single FITS copy assumes these three
   samples are the only entries in the list.
7. Quit normally and reopen FrameScout. Confirm review decisions and notes
   persist. Keep the extracted source files at the same location for this
   test so the app can retain access to them.

The sample statistics are descriptive and are not a complete image-quality
assessment. These three files exercise the ordinary review workflow;
they do not cover every supported FITS encoding.
