AstroNote for FITS — App Review Samples (1.0 workflow)

Extract the ZIP before opening the files in Samples. No sign-in or
companion application is needed for the standalone workflow below.

FILES
01_Synthetic_Nebula.fits: 512 x 512 floating-point, uncompressed 2D FITS
primary image (HDU 0), generated from the app's synthetic nebula example.
02_Nebula_Preview.png: grayscale preview of the same FITS image, for testing
ordinary image import. This is a display image, not scientific pixel data.
03_Example_Annotations.astronote: ready-to-import annotation package with
an embedded reference preview, a point, a rectangular region, a text
annotation, and an overall observation note. It matches the included FITS
file's SHA-256 fingerprint, original dimensions and HDU index.

QUICK START: IMPORT A COMPLETE EXAMPLE
1. Launch AstroNote and choose Import annotation package... . Select
   03_Example_Annotations.astronote. If a draft-replacement prompt appears,
   export any draft you want to retain before choosing to replace it.
2. Confirm the reference image and three annotations are visible. Select
   an annotation in the left list. Edit its title and note. Edit the
   overall observation note and record title as well.
3. Export an annotation package to a new file using Export annotation
   package... . Import that exported file and confirm the edits remain.
4. Use Export PNG... to save the image with annotations, and Export
   notes... to save a text version of the notes.

CREATE ANNOTATIONS ON A FITS IMAGE
5. Use Open FITS / Image... to open 01_Synthetic_Nebula.fits. Export the
   previous draft first if you wish to preserve it, then confirm switching.
6. Select the point tool and click a feature on the image. Choose the
   text tool and click elsewhere. Choose the region tool and drag a
   rectangle. Choose Amber, Cyan or Pink when creating annotations.
7. Select each annotation in the list and edit its title and note.
   Use Delete annotation, then Undo to restore it. Undo handles annotation
   additions/deletions; text editing uses standard system text behavior.
8. Fill in the overall observation note. Export the annotation package,
   annotated PNG and text notes. These operations leave the FITS file
   unchanged. An annotation package contains a reduced reference preview
   and notes/metadata, not the original FITS pixel data.
9. Quit normally and reopen AstroNote. Confirm the most recent draft,
   including its image preview and notes, is restored automatically.

ORDINARY IMAGE AND BUILT-IN EXAMPLE
10. Use Open FITS / Image... to open 02_Nebula_Preview.png and try the
    same annotation/export workflow. Save any existing draft first.
11. Built-in example provides another immediate starting point without
    downloading a file. Switching images replaces the current draft after
    confirmation when applicable; export a package to preserve a record.

COORDINATES AND OPTIONAL HOST INTEGRATION
Annotation coordinates are normalized display coordinates from 0 to 1,
with the origin at the upper-left. They are not FITS pixel coordinates
or sky coordinates. PNG output is a preview, not full-resolution science
data. This sample is synthetic and does not represent an observation.
If reviewing optional FITS QuickLook Studio integration, import the
.astronote package through that app's Extensions > AstroNote and open the
included original FITS file. Overlay matching requires the same file
fingerprint, original dimensions and HDU. The companion is not required
for any of the standalone import, editing, draft or export steps above.

VALIDATION
The FITS and PNG were successfully read with the local AstroNote code.
The .astronote package was validated, written and read back identically
with the app's package code. Its FITS fingerprint/dimension/HDU match
was checked. All three annotation types are present. This verifies the
sample data and package structure, not a new App Store build or a complete
end-to-end UI test.
