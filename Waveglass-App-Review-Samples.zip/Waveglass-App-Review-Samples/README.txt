Waveglass / Waveglass Mobile — App Review Samples

Eight synthetic JSON design files, shared by macOS and iPadOS.
These designs were serialized from the local application models. The same
files were decoded, validated and solved with BOTH local platform cores.
This is core-level verification, not a new App Store build or device UI test.

OPENING THE FILES
Mac: extract the ZIP in Finder. In Waveglass use Open / Open Design... and
select a .json file inside Samples.
iPad: download the ZIP in Safari, locate it in Files (Downloads), tap it to
extract it, then return to Waveglass Mobile and use Open to select a .json
file from the extracted Samples folder. Do not select the ZIP itself.
On iPad, the toolbar Parameters slider icon opens the editing panel; tap
Done before running. Reveal the sidebar with its button in narrow windows.
No sign-in, server, paid activation or other installed scientific app is
required for the local simulation workflow. Built-in Examples also work
without downloading any file.

FILES AND TEST STEPS
01_Straight_TE.json: start on the Modeling & Simulation page and Run Solver.
Inspect Mode Analysis, Field Propagation and Wavelength Sweep. This design
produces two guided modes and 15 wavelength samples with the current core.
The guided effective indices lie between the cladding and core indices.
02_Taper_TE.json: open and run; inspect the changing guide width in the
propagation view and the resulting power/output projection information.
03_Coupler_TE.json: open and run; inspect the two-guide geometry, field
propagation and channel power monitors. Four input guided modes are found.
04_S_Bend_TE.json: open and run; inspect the curved guide and propagated field.
05_Straight_TM.json: open and run; inspect TM modes and wavelength sweep.
TM propagation is intentionally unavailable; this is not a failed solve.
06_Cross_Channel.json, 07_Cross_Rib.json, 08_Cross_Pair.json: after opening,
select 2D Cross Section BEFORE Run Solver. Inspect intensity/signed field,
effective index, area, confinement and the basis-order comparison. Current
cores find respectively 3, 5 and 6 modes. These are scalar cross sections;
the planar TE/TM switch does not turn them into a full-vector solver.

CONVERGENCE, EDITING AND EXPORT
Reopen 01_Straight_TE.json, select Convergence & Quality, and Run Solver to
compare coarse/base/fine grids and an expanded window. A reported change
above the displayed tolerance is a diagnostic, not an import failure.
Change a parameter (for example wavelength), then rerun to refresh results.
Old results may be marked stale until rerun. Save the modified JSON under
a new name; reopen it and run again. Computed results are not embedded in
the design file. Use Cancel during an active computation to test cancellation.
Export the current study as CSV or a Markdown report. After a TE propagation
or 2D cross-section solve, export a PNG field image. On iPad choose a location
in the system file exporter. Keep the reference sample files unchanged.

MODEL SCOPE
All lengths use micrometers. Planar TE/TM modes, scalar paraxial TE BPM,
scalar 2D cross sections and fixed-index wavelength sweeps have different
physical scopes. No full-vector 3D/FDTD, TM BPM, material dispersion or
true PML is claimed. The in-app guide explains the numerical assumptions.
